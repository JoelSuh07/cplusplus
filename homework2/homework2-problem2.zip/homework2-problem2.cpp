#include <iostream>
using namespace std;

/*
int main(){
    for (int i=5;i>=0;i--){
        for (int j=i;j>=0;j--){
            cout << "* "; 
        }
     cout << endl;
        for (int k=i;k<=5;k++){
            cout << "* ";
        }
        cout << endl;
    }
}
    */